/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package main;

/**
 *
 * @author Viet Anh
 */
public class CSE305_Project {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
